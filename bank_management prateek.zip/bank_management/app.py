from flask import Flask, render_template, request, redirect, session
from config import get_db_connection

app = Flask(__name__)
app.secret_key = "secret123"   # for session handling


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]

        conn = get_db_connection()
        cur = conn.cursor()

        cur.execute("INSERT INTO users (username, password) VALUES (%s, %s)", 
                    (username, password))
        conn.commit()

        cur.close()
        conn.close()

        return redirect("/")
    return render_template("register.html")


@app.route("/login", methods=["POST"])
def login():
    username = request.form["username"]
    password = request.form["password"]

    conn = get_db_connection()
    cur = conn.cursor(dictionary=True)

    cur.execute("SELECT * FROM users WHERE username=%s AND password=%s", 
                (username, password))
    user = cur.fetchone()

    cur.close()
    conn.close()

    if user:
        session["user_id"] = user["id"]
        session["username"] = user["username"]
        return redirect("/dashboard")
    else:
        return "Invalid login! <a href='/'>Try again</a>"


@app.route("/dashboard")
def dashboard():
    if "user_id" not in session:
        return redirect("/")
    
    conn = get_db_connection()
    cur = conn.cursor(dictionary=True)
    cur.execute("SELECT balance FROM users WHERE id=%s", (session["user_id"],))
    balance = cur.fetchone()["balance"]

    cur.close()
    conn.close()

    return render_template("dashboard.html", username=session["username"], balance=balance)


@app.route("/deposit", methods=["POST"])
def deposit():
    if "user_id" not in session:
        return redirect("/login")

    amount = float(request.form["amount"])
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("UPDATE users SET balance = balance + %s WHERE id=%s", (amount, session["user_id"]))
    conn.commit()
    cur.close()
    conn.close()
    return redirect("/dashboard")


@app.route("/withdraw", methods=["POST"])
def withdraw():
    if "user_id" not in session:
        return redirect("/login")

    amount = float(request.form["amount"])
    conn = get_db_connection()
    cur = conn.cursor(dictionary=True)

    # Check current balance
    cur.execute("SELECT balance FROM users WHERE id=%s", (session["user_id"],))
    balance = cur.fetchone()["balance"]

    if amount <= balance:  # only allow if enough money
        cur.execute("UPDATE users SET balance = balance - %s WHERE id=%s", (amount, session["user_id"]))
        conn.commit()

    cur.close()
    conn.close()
    return redirect("/dashboard")

@app.route("/logout")
def logout():
    session.clear()
    return redirect("/")
    

if __name__ == "__main__":
    app.run(debug=True)