import mysql.connector

def get_db_connection():
    conn = mysql.connector.connect(
        host="localhost",
        user="root",      # MySQL username
        password="cnpsrtfd",  # MySQL password
        database="bank_system"
    )
    return conn